function [x_sortf,y_sortf] = backbone(x_sort,y_sort)
ne = size(x_sort,1);
x_sortf = [0];
y_sortf = [0];
ref_vec = [0,1];
for i=3:(ne-11)
    if (y_sort(i)>=0 && dot(ref_vec,[x_sort(i-1)-x_sort(i-2),y_sort(i-1)-y_sort(i-2)])>=0 && dot(ref_vec,[x_sort(i)-x_sort(i-1),y_sort(i)-y_sort(i-1)])>=0 && dot(ref_vec,[x_sort(i+1)-x_sort(i),y_sort(i+1)-y_sort(i)])<=0 && dot(ref_vec,[x_sort(i+2)-x_sort(i+1),y_sort(i+2)-y_sort(i+1)])<=0 && dot(ref_vec,[x_sort(i+3)-x_sort(i+2),y_sort(i+3)-y_sort(i+2)])<=0 && dot(ref_vec,[x_sort(i+4)-x_sort(i+3),y_sort(i+4)-y_sort(i+3)])<=0 && dot(ref_vec,[x_sort(i+5)-x_sort(i+4),y_sort(i+5)-y_sort(i+4)])<=0 && dot(ref_vec,[x_sort(i+6)-x_sort(i+5),y_sort(i+6)-y_sort(i+5)])<=0 && dot(ref_vec,[x_sort(i+7)-x_sort(i+6),y_sort(i+7)-y_sort(i+6)])<=0 && dot(ref_vec,[x_sort(i+8)-x_sort(i+7),y_sort(i+8)-y_sort(i+7)])<=0 && dot(ref_vec,[x_sort(i+9)-x_sort(i+8),y_sort(i+9)-y_sort(i+8)])<=0 && dot(ref_vec,[x_sort(i+10)-x_sort(i+9),y_sort(i+10)-y_sort(i+9)])<=0)||...
    (y_sort(i)<0 && dot(ref_vec,[x_sort(i-1)-x_sort(i-2),y_sort(i-1)-y_sort(i-2)])<=0 && dot(ref_vec,[x_sort(i)-x_sort(i-1),y_sort(i)-y_sort(i-1)])<=0 && dot(ref_vec,[x_sort(i+1)-x_sort(i),y_sort(i+1)-y_sort(i)])>=0 && dot(ref_vec,[x_sort(i+2)-x_sort(i+1),y_sort(i+2)-y_sort(i+1)])>=0 && dot(ref_vec,[x_sort(i+3)-x_sort(i+2),y_sort(i+3)-y_sort(i+2)])>=0 && dot(ref_vec,[x_sort(i+4)-x_sort(i+3),y_sort(i+4)-y_sort(i+3)])>=0 && dot(ref_vec,[x_sort(i+5)-x_sort(i+4),y_sort(i+5)-y_sort(i+4)])>=0 && dot(ref_vec,[x_sort(i+6)-x_sort(i+5),y_sort(i+6)-y_sort(i+5)])>=0 && dot(ref_vec,[x_sort(i+7)-x_sort(i+6),y_sort(i+7)-y_sort(i+6)])>=0 && dot(ref_vec,[x_sort(i+8)-x_sort(i+7),y_sort(i+8)-y_sort(i+7)])>=0 && dot(ref_vec,[x_sort(i+9)-x_sort(i+8),y_sort(i+9)-y_sort(i+8)])>=0 && dot(ref_vec,[x_sort(i+10)-x_sort(i+9),y_sort(i+10)-y_sort(i+9)])>=0)
        x_sortf = [x_sortf;x_sort(i)];
        y_sortf = [y_sortf;y_sort(i)];
    end
end
[x_sortf,index] = sort(x_sortf);
y_sortf = y_sortf(index);
end