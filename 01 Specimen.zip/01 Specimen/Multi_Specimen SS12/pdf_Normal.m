%% pdf_Normal: Normal Probability Density Function
%
% Usage:
%   x = pdf_Normal(N, mu, sigma)
%
% Inputs:
%     N                scalar, number of samples
%     mu               mean
%     sigma            standard deviation
%
% Output:
%     x                vector with the sampled data
%                      if N==0 -> x = [mu - 3*sigma, mu + 3*sigma]  
%
% ------------------------------------------------------------------------

function x = pdf_Normal(N, mu, sigma)

if N==0
    x = [mu - 3*sigma, mu + 3*sigma];
else
    % sample a normal distribution function 
    x = normrnd(mu,sigma, [N 1]);% simulating Nx1 normal random numbers
end
    
