function [ener,history_ener] = energy(rotation,moment)
n = size(rotation,1);
history_ener = zeros(n,1);
history_ener(1) = 0.5*moment(1)*rotation(1);
for k = 2:n
    history_ener(k) = history_ener(k-1)+0.5*(moment(k)+moment(k-1))*(rotation(k)-rotation(k-1));
end
ener = history_ener(n,1);
end