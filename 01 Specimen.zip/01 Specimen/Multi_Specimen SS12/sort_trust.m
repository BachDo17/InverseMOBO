function [x_trust,y_trust,del] = sort_trust(x_data,y_data,x_best,delta)
% x_data = N by D
% y_data = N by d
% x_best = 1 by D
% delta = 1 by 1
[N,D] = size(x_data);
p = 2;
x_trust = []; y_trust = [];
% Normalized data
x_norm = (x_data-min(x_data))./(max(x_data)-min(x_data));
x_best_norm = (x_best-min(x_data))./(max(x_data)-min(x_data));
for i = 1:N
    if norm(x_norm(i,:)-x_best_norm,p) <= delta
        x_trust = [x_trust;x_data(i,:)];
        y_trust = [y_trust;y_data(i,:)];
    end
end
while size(x_trust,1)<D
    delta = 2*delta;
    x_trust = []; y_trust = [];
    for i = 1:N
    if norm(x_norm(i,:)-x_best_norm,p) <= delta
        x_trust = [x_trust;x_data(i,:)];
        y_trust = [y_trust;y_data(i,:)];
    end
    end
end
del = delta;
end